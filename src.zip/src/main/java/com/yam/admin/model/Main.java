package com.yam.admin.model;

public class Main {

}
